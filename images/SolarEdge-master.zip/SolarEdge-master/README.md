
**Simple Youtube Importer**
=======
A simple Video Importer For Youtube Videos,
Imports Video By ID

 - **[Live Demo](https://marik22312.github.io/SolarEdge)**

**Developed By:** [Marik Sh](http://www.facebook.com/marik.sh), [Asaf Hadad](https://www.facebook.com/asaf.hadad2)

**Version:** 1.0


----------

How To Use
----------



**Change Video In Category**

 1. Go to the category that you want to change a video
 2. Find the desired video
 3. change VideoID, name & desc value to the desired video values from Youtube
 for example to change "Moby - Everloving" to "Frank Sinatra Fly Me To The Moon"
 You will have to change this:


         {
        videoID: "atyvdC15HFA",
        name: "Moby - Everloving",
        desc: "Description Goes Here",
	     },

Into this:

         {
        videoID: "mQR0bXO_yI8",
        name: "Frank Sinatra Fly Me To The Moon",
        desc: "Description Goes Here",
	     },
